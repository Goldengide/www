catholicapp-api
===============

This is the API implementation of the Catholic Mobile Application. It was developed using the Slim PHP framework and Laravel Eloquent ORM as its functional ORM.


The API documentation can be viewed on the url: https://docs.google.com/document/d/1mCaJaWqQ1qhwJ3IjRFEVMbKOmsdatNwnnoMgI1kz_Ns/edit.